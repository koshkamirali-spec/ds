# J.A.R.V.I.S — Cyber Expanded Development Build

This Flutter source expands the cyber interface with working local utilities and OS hand-offs.

## Included
- Animated cyber UI (rotating HUD, pulsing core, ambient grid).
- Gemini REST client (requires a Gemini API key entered in Settings).
- Local notes, tasks, and recent conversation history.
- Persian speech recognition input and text-to-speech response.
- Camera preview and photo capture screen (camera permission required).
- External web search, Maps, current-location handoff (after location permission), weather search, YouTube Music, dialer and SMS composer.
- Saved smart-mode profile and phrase-to-response custom commands.
- Emergency dialer hand-off only after explicit confirmation.
- GitHub Actions workflow that creates the Android scaffold when absent, runs analysis, builds a release APK, and uploads it as an artifact.

## Build locally
```bash
flutter create --platforms=android --project-name jarvis_assistant .
python3 tooling/patch_android_manifest.py
flutter pub get
flutter analyze
flutter build apk --release
```

APK: `build/app/outputs/flutter-apk/app-release.apk`

## GitHub Actions
Push the repository to `main`, or open Actions and run **Build JARVIS Android APK** manually. Download the `jarvis-release-apk` artifact from the successful run.

## Important limitations
This is an expanded development build, not a fully tested final product. Hey Jarvis always-on wake word, true system-wide phone control, in-app web result parsing, image understanding, scheduled notifications, secure cloud backend, and media-session controls are not implemented. Android/iOS may require additional permissions and native configuration. The Gemini key saved in the app is not protected from extraction; do not use a personal production key in a publicly distributed APK.
