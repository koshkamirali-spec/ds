# Android native integration
مجوزها، سرویس foreground، wake-word و کنترل دستگاه باید در AndroidManifest.xml و Kotlin پیاده‌سازی و روی نسخه‌های هدف تست شوند. این README جایگزین پیاده‌سازی native نیست.
