# Backend placeholder
برای استفاده واقعی از Gemini و سرویس‌های بیرونی، backend امن اضافه کنید. کلیدهای API را داخل اپ یا GitHub repository قرار ندهید. این پوشه به‌تنهایی سرور اجرایی نیست.
