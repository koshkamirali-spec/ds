# Cyber smooth home interface

Implemented in `lib/core/app_shell.dart` using Flutter's built-in animation and CustomPainter APIs (no new packages).

- Animated cyber grid and ambient cyan glow.
- Rotating orbital HUD, breathing core, and animated audio-style bars.
- Processing state changes the core accent and status label.
- Glass-like command panel and feature cards.
- Command input and execute button invoke the existing local `CommandRouter`.
- Every feature card opens a bottom sheet with its actual implementation status and description; the cards do not pretend unavailable integrations are active.

The Gemini, wake-word, phone-control, camera, and web integrations remain dependent on API credentials, permissions, native implementation, or external providers as described by `FeatureRegistry`.
