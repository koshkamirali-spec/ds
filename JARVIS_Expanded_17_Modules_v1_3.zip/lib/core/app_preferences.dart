import 'package:shared_preferences/shared_preferences.dart';

class AppPreferences {
  static const _geminiKey = 'jarvis_gemini_api_key';
  static Future<String> getGeminiKey() async =>
      (await SharedPreferences.getInstance()).getString(_geminiKey) ?? '';
  static Future<void> setGeminiKey(String value) async =>
      (await SharedPreferences.getInstance()).setString(_geminiKey, value.trim());
}
