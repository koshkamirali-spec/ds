import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:jarvis_assistant/core/feature_registry.dart';
import 'package:jarvis_assistant/core/task_store.dart';
import 'package:jarvis_assistant/services/command_router.dart';
import 'package:jarvis_assistant/services/gemini_service.dart';
import 'package:jarvis_assistant/core/app_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import '../screens/camera_screen.dart';

const _cyan = Color(0xFF27D9FF);
const _blue = Color(0xFF3478FF);
const _violet = Color(0xFF9B6BFF);
const _panel = Color(0xCC101A2A);

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with TickerProviderStateMixin {
  final input = TextEditingController();
  final tasks = TaskStore();
  final gemini = GeminiService();
  final speech = stt.SpeechToText();
  final tts = FlutterTts();
  bool listening = false;
  bool speechAvailable = false;
  late final AnimationController _ambient = AnimationController(vsync: this, duration: const Duration(seconds: 9))..repeat();
  late final AnimationController _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 2100), lowerBound: .94, upperBound: 1)..repeat(reverse: true);
  String response = 'سلام. من J.A.R.V.I.S هستم. فرمانت را وارد کن.';
  bool busy = false;

  @override
  void dispose() { input.dispose(); _ambient.dispose(); _pulse.dispose(); if (listening) speech.stop(); tts.stop(); super.dispose(); }

  Future<void> _settings() async {
    final controller = TextEditingController(text: await AppPreferences.getGeminiKey());
    if (!mounted) return;
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF101B2B),
      title: const Text('تنظیمات هوش مصنوعی'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('کلید Gemini را وارد کن. برای نسخه عمومی و امن، بهتر است درخواست‌ها از بک‌اند خودت عبور کنند؛ کلید ذخیره‌شده در اپ قابل استخراج است.', style: TextStyle(color: Color(0xFFB8C7D9), height: 1.6)),
        const SizedBox(height: 12),
        TextField(controller: controller, obscureText: true, decoration: const InputDecoration(labelText: 'Gemini API Key', border: OutlineInputBorder())),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')), FilledButton(onPressed: () async { await AppPreferences.setGeminiKey(controller.text); if (ctx.mounted) Navigator.pop(ctx); if (mounted) setState(() {}); }, child: const Text('ذخیره'))],
    ));
    controller.dispose();
  }

  Future<void> _toggleVoice() async {
    if (listening) { await speech.stop(); if (mounted) setState(() => listening = false); return; }
    speechAvailable = await speech.initialize(onStatus: (status) { if (status == 'done' || status == 'notListening') { if (mounted) setState(() => listening = false); } }, onError: (_) { if (mounted) setState(() => listening = false); });
    if (!speechAvailable) { if (mounted) setState(() => response = 'تشخیص گفتار در این دستگاه در دسترس نیست یا مجوز میکروفون داده نشده است.'); return; }
    if (mounted) setState(() => listening = true);
    await speech.listen(localeId: 'fa_IR', listenFor: const Duration(seconds: 25), onResult: (result) { if (mounted) { input.text = result.recognizedWords; input.selection = TextSelection.collapsed(offset: input.text.length); if (result.finalResult) setState(() => listening = false); } });
  }

  Future<void> _speakResponse() async { await tts.setLanguage('fa-IR'); await tts.setSpeechRate(0.48); await tts.speak(response); }

  Future<void> run() async {
    final q = input.text.trim();
    if (q.isEmpty || busy) return;
    FocusScope.of(context).unfocus();
    setState(() { busy = true; response = 'در حال پردازش فرمان...'; });
    String result;
    try {
      result = await CommandRouter(tasks).handle(q);
      if (result.startsWith('این فرمان در نسخه فعلی') || result.startsWith('این فرمان محلی شناخته نشد')) {
        final key = await AppPreferences.getGeminiKey();
        if (key.isNotEmpty) { result = await gemini.ask(apiKey: key, prompt: q); }
        else { result = '$result\nبرای فعال‌کردن پاسخ هوشمند، از آیکون تنظیمات کلید Gemini را ثبت کن.'; }
      }
    } catch (e) { result = 'ارتباط با سرویس انجام نشد: $e'; }
    if (!mounted) return;
    setState(() { response = result; busy = false; });
    await tasks.addHistory('شما: $q');
    await tasks.addHistory('JARVIS: $result');
    input.clear();
  }


  Future<void> _activateFeature(FeatureInfo feature) async {
    switch (feature.id) {
      case 'ai': await _settings(); return;
      case 'voice': await _toggleVoice(); return;
      case 'vision':
        if (!mounted) return;
        await Navigator.push(context, MaterialPageRoute(builder: (_) => const JarvisCameraScreen()));
        return;
      case 'web':
        await _promptAndOpen('جست‌وجوی وب', 'عبارت موردنظر را وارد کن', (v) =>
          Uri.parse('https://www.google.com/search?q=${Uri.encodeQueryComponent(v)}'));
        return;
      case 'memory':
        final history = await tasks.history();
        if (!mounted) return;
        showDialog<void>(context: context, builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF101B2B), title: const Text('حافظه مکالمات'),
          content: SizedBox(width: double.maxFinite, child: history.isEmpty
            ? const Text('هنوز مکالمه‌ای ذخیره نشده.')
            : ListView(shrinkWrap: true, children: history.reversed.take(40).map((e) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 5), child: Text(e, style: const TextStyle(color: Color(0xFFD8E5F5))))).toList())),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('بستن'))],
        ));
        return;
      case 'tools':
        final notes = await tasks.all();
        final todo = await tasks.allTasks();
        if (!mounted) return;
        showDialog<void>(context: context, builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF101B2B), title: const Text('ابزارهای روزانه'),
          content: Text('یادداشت‌ها: ${notes.length}\nوظایف: ${todo.length}\n\nفرمان‌ها:\nیادداشت متن\nوظیفه متن\nیادداشت‌ها\nوظایف\nساعت\nتاریخ\nجستجو عبارت\nنقشه مقصد\nآب و هوا'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('متوجه شدم'))],
        ));
        return;
      case 'device':
        await openAppSettings();
        return;
      case 'comms':
        await _communicationDialog();
        return;
      case 'emergency':
        await _emergencyDialog();
        return;
      case 'media':
        await launchUrl(Uri.parse('https://music.youtube.com/'), mode: LaunchMode.externalApplication);
        return;
      case 'modes':
        await _modeDialog();
        return;
      case 'custom':
        await _customCommandDialog();
        return;
      case 'settings':
        await _settings();
        return;
      case 'wake':
        _showInfo(feature, 'فعال‌سازی دائمی کلمه بیدارباش در پس‌زمینه در این نسخه فعال نیست. Android برای سرویس دائمی، اعلان foreground و تنظیمات باتری لازم دارد؛ iOS محدودیت بیشتری دارد.');
        return;
      case 'backend':
        _showInfo(feature, 'برای محافظت از کلیدها، نسخه عمومی باید از بک‌اند امن استفاده کند. کلید واردشده در اپ محلی قابل استخراج است. فعلاً ارتباط مستقیم Gemini در دستگاه استفاده می‌شود.');
        return;
      case 'cicd':
        _showInfo(feature, 'Workflow گیت‌هاب می‌تواند APK آزمایشی بسازد. برای انتشار عمومی باید کلید امضای Android را به‌صورت GitHub Secrets تنظیم و نسخه release امضا شود.');
        return;
      case 'architecture':
        _showInfo(feature, 'ساختار فعلی سرویس‌ها را جدا کرده است: مسیریاب فرمان، ذخیره‌سازی محلی، Gemini و رابط کاربری. برای محصول نهایی تست خودکار و بک‌اند امن همچنان لازم است.');
        return;
      default:
        _showInfo(feature, feature.description);
    }
  }

  void _showInfo(FeatureInfo feature, String detail) {
    showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF101B2B),
      title: Text(feature.title),
      content: Text(detail, style: const TextStyle(height: 1.7)),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('باشه'))],
    ));
  }

  Future<void> _promptAndOpen(String title, String hint, Uri Function(String) buildUri) async {
    final c = TextEditingController();
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF101B2B), title: Text(title),
      content: TextField(controller: c, autofocus: true, decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
        FilledButton(onPressed: () async {
          final value = c.text.trim();
          if (value.isEmpty) return;
          Navigator.pop(ctx);
          await launchUrl(buildUri(value), mode: LaunchMode.externalApplication);
        }, child: const Text('باز کردن')),
      ],
    ));
    c.dispose();
  }

  Future<void> _communicationDialog() async {
    final choice = await showModalBottomSheet<String>(context: context, backgroundColor: const Color(0xFF101B2B), builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.call, color: _cyan), title: const Text('تماس'), onTap: () => Navigator.pop(ctx, 'call')),
        ListTile(leading: const Icon(Icons.sms, color: _cyan), title: const Text('نوشتن پیامک'), onTap: () => Navigator.pop(ctx, 'sms')),
        ListTile(leading: const Icon(Icons.map, color: _cyan), title: const Text('بازکردن نقشه'), onTap: () => Navigator.pop(ctx, 'map')),
      ]),
    ));
    if (choice == 'call') {
      await _promptAndOpen('تماس تلفنی', 'شماره تلفن', (v) => Uri(scheme: 'tel', path: v));
    } else if (choice == 'sms') {
      final c = TextEditingController();
      final m = TextEditingController();
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF101B2B), title: const Text('پیامک'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: c, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره')),
          TextField(controller: m, decoration: const InputDecoration(labelText: 'متن پیام')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('لغو')),
          FilledButton(onPressed: () async { if(c.text.trim().isEmpty) return; Navigator.pop(ctx); await launchUrl(Uri(scheme:'sms',path:c.text.trim(),queryParameters:{'body':m.text})); }, child: const Text('باز کردن پیامک')),
        ],
      ));
      c.dispose(); m.dispose();
    } else if (choice == 'map') {
      await _promptAndOpen('مسیریابی', 'نام مقصد', (v) => Uri.parse('https://www.google.com/maps/search/?api=1&query=${Uri.encodeQueryComponent(v)}'));
    }
  }

  Future<void> _emergencyDialog() async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF101B2B), title: const Text('تماس اضطراری'),
      content: const Text('در صورت خطر فوری، شماره اضطراری محل زندگی‌ات را فقط در صورت نیاز واقعی تماس بگیر. آیا می‌خواهی صفحه تماس اضطراری باز شود؟'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ادامه')),
      ],
    ));
    if (ok == true) {
      await launchUrl(Uri(scheme: 'tel', path: '112'));
    }
  }

  Future<void> _modeDialog() async {
    final prefs = await SharedPreferences.getInstance();
    String current = prefs.getString('jarvis_mode') ?? 'عادی';
    final modes = ['عادی','تمرکز','رانندگی','خانه','کار'];
    if (!mounted) return;
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setLocal) => AlertDialog(
      backgroundColor: const Color(0xFF101B2B), title: const Text('حالت هوشمند'),
      content: Column(mainAxisSize: MainAxisSize.min, children: modes.map((m) => RadioListTile<String>(
        value:m, groupValue:current, title:Text(m), onChanged:(v)=>setLocal(()=>current=v!),
      )).toList()),
      actions: [FilledButton(onPressed: () async { await prefs.setString('jarvis_mode', current); if(ctx.mounted) Navigator.pop(ctx); if(mounted) setState(()=>response='حالت $current فعال شد.'); }, child: const Text('ذخیره حالت'))],
    )));
  }

  Future<void> _customCommandDialog() async {
    final prefs = await SharedPreferences.getInstance();
    final c = TextEditingController();
    final r = TextEditingController();
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF101B2B), title: const Text('فرمان اختصاصی'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller:c, decoration:const InputDecoration(labelText:'عبارت فرمان')),
        TextField(controller:r, decoration:const InputDecoration(labelText:'پاسخ ذخیره‌شده')),
      ]),
      actions: [
        TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('لغو')),
        FilledButton(onPressed:() async {
          if(c.text.trim().isEmpty || r.text.trim().isEmpty) return;
          final list=prefs.getStringList('jarvis_custom_commands')??[];
          list.removeWhere((e)=>e.startsWith('${c.text.trim()}|'));
          list.add('${c.text.trim()}|${r.text.trim()}');
          await prefs.setStringList('jarvis_custom_commands',list);
          if(ctx.mounted) Navigator.pop(ctx);
          if(mounted) setState(()=>response='فرمان اختصاصی ذخیره شد. در چت عبارت «${c.text.trim()}» را وارد کن.');
        },child:const Text('ذخیره')),
      ],
    ));
    c.dispose(); r.dispose();
  }

  void _showFeature(FeatureInfo feature) { _activateFeature(feature); }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFF070C16),
        body: Stack(children: [
          Positioned.fill(child: AnimatedBuilder(animation: _ambient, builder: (_, __) => CustomPaint(painter: _CyberBackgroundPainter(_ambient.value)))),
          SafeArea(child: CustomScrollView(slivers: [
            SliverPadding(padding: const EdgeInsets.fromLTRB(18, 12, 18, 28), sliver: SliverList(delegate: SliverChildListDelegate([
              Row(children: [
                const Expanded(child: Text('J.A.R.V.I.S', textDirection: TextDirection.ltr, style: TextStyle(fontSize: 25, letterSpacing: 4, fontWeight: FontWeight.w300, color: Colors.white))),
                IconButton(tooltip: 'تنظیمات Gemini', onPressed: _settings, icon: const Icon(Icons.settings_outlined, color: _cyan)),
                IconButton(tooltip: 'درباره برنامه', onPressed: () => showAboutDialog(context: context, applicationName: 'J.A.R.V.I.S', applicationVersion: '1.2.0'), icon: const Icon(Icons.info_outline, color: _cyan)),
              ]),
              const SizedBox(height: 14),
              _HeroPanel(ambient: _ambient, pulse: _pulse, busy: busy),
              const SizedBox(height: 15),
              _GlassPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [const Icon(Icons.terminal_rounded, color: _cyan, size: 19), const SizedBox(width: 8), const Text('رابط فرمان', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)), const Spacer(), _StatusPill(text: busy ? 'در حال پردازش' : 'آماده')]),
                const SizedBox(height: 12),
                TextField(controller: input, textInputAction: TextInputAction.send, onSubmitted: (_) => run(), style: const TextStyle(color: Colors.white), decoration: InputDecoration(hintText: 'مثلاً: یادداشت خرید نان', hintStyle: const TextStyle(color: Colors.white38), filled: true, fillColor: const Color(0xFF080F1C), prefixIcon: const Icon(Icons.keyboard_command_key, color: _cyan), contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0x6643CFFF))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _cyan, width: 1.5)))),
                const SizedBox(height: 10),
                Row(children: [Expanded(child: SizedBox(height: 48, child: DecoratedBox(decoration: BoxDecoration(gradient: const LinearGradient(colors: [_cyan, Color(0xFF4C9BFF)]), borderRadius: BorderRadius.circular(14), boxShadow: [BoxShadow(color: _cyan.withOpacity(.18), blurRadius: 18)]), child: ElevatedButton.icon(onPressed: busy ? null : run, icon: busy ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF06101D))) : const Icon(Icons.arrow_back_rounded), label: Text(busy ? 'لطفاً صبر کن' : 'اجرای فرمان'), style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, disabledBackgroundColor: Colors.transparent, foregroundColor: const Color(0xFF06101D), disabledForegroundColor: const Color(0xFF06101D), shadowColor: Colors.transparent, textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)))))), const SizedBox(width: 8), SizedBox(height: 48, width: 54, child: OutlinedButton(onPressed: _toggleVoice, style: OutlinedButton.styleFrom(foregroundColor: listening ? _violet : _cyan, side: BorderSide(color: listening ? _violet : _cyan)), child: Icon(listening ? Icons.mic : Icons.mic_none))) ]),
                const SizedBox(height: 13),
                AnimatedSwitcher(duration: const Duration(milliseconds: 350), child: Container(key: ValueKey(response), padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: const Color(0xFF080F1B), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(.06))), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(busy ? Icons.sync : Icons.chat_bubble_outline, color: _cyan, size: 18), const SizedBox(width: 9), Expanded(child: SelectableText(response, style: const TextStyle(color: Color(0xFFD8E5F5), height: 1.7, fontSize: 14))), IconButton(tooltip: 'خواندن پاسخ', onPressed: _speakResponse, icon: const Icon(Icons.volume_up_outlined, color: _cyan, size: 19))]))),
              ])),
              const SizedBox(height: 22),
              Row(children: [const Text('مصفوفة الأنظمة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const Spacer(), Text('${FeatureRegistry.features.length} وحدة', style: const TextStyle(color: Colors.white38, fontSize: 12))]),
              const SizedBox(height: 5),
              const Text('برای دیدن وضعیت و توضیح هر قابلیت، کارت آن را لمس کن.', style: TextStyle(color: Colors.white38, fontSize: 12)),
              const SizedBox(height: 12),
              ...FeatureRegistry.features.asMap().entries.map((entry) => Padding(padding: const EdgeInsets.only(bottom: 9), child: _FeatureTile(feature: entry.value, index: entry.key, onTap: () => _showFeature(entry.value)))),
              const SizedBox(height: 10),
              const Center(child: Text('J.A.R.V.I.S  •  CYBER INTERFACE', textDirection: TextDirection.ltr, style: TextStyle(color: Colors.white24, letterSpacing: 2, fontSize: 10))),
            ]))),
          ])),
        ]),
      ),
    );
  }
}

class _HeroPanel extends StatelessWidget {
  const _HeroPanel({required this.ambient, required this.pulse, required this.busy});
  final Animation<double> ambient, pulse;
  final bool busy;
  @override
  Widget build(BuildContext context) => _GlassPanel(padding: const EdgeInsets.fromLTRB(18, 18, 18, 16), child: Column(children: [
    SizedBox(height: 190, child: AnimatedBuilder(animation: Listenable.merge([ambient, pulse]), builder: (_, __) => Stack(alignment: Alignment.center, children: [
      CustomPaint(size: const Size(210, 180), painter: _OrbitalPainter(ambient.value)),
      Transform.scale(scale: pulse.value, child: Container(width: 112, height: 112, decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [const Color(0xFF54E9FF).withOpacity(.36), const Color(0xFF2467FF).withOpacity(.14), Colors.transparent]), boxShadow: [BoxShadow(color: (busy ? _violet : _cyan).withOpacity(.34), blurRadius: 34, spreadRadius: 8)]), child: Center(child: Container(width: 66, height: 66, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: busy ? _violet : _cyan, width: 1.5), color: const Color(0xFF0C1C32), boxShadow: [BoxShadow(color: (busy ? _violet : _cyan).withOpacity(.45), blurRadius: 22)]), child: Icon(busy ? Icons.auto_awesome : Icons.blur_on_rounded, size: 36, color: busy ? _violet : _cyan))))),
      Positioned(top: 7, child: Text(busy ? 'PROCESSING' : 'SYSTEM ONLINE', textDirection: TextDirection.ltr, style: TextStyle(color: busy ? const Color(0xFFCAADFF) : _cyan, fontSize: 10, letterSpacing: 3, fontWeight: FontWeight.w600))),
      Positioned(bottom: 5, child: Row(mainAxisSize: MainAxisSize.min, children: List.generate(21, (i) { final wave = (math.sin((ambient.value * math.pi * 2) + i * .55).abs() * 17 + 4) * (busy ? 1.3 : .75); return Container(width: 2.5, height: wave, margin: const EdgeInsets.symmetric(horizontal: 2), decoration: BoxDecoration(color: _cyan.withOpacity(.45 + (wave / 40)), borderRadius: BorderRadius.circular(4))); }))),
    ]))),
    const Text('دستیار هوشمند یکپارچه', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
    const SizedBox(height: 5),
    const Text('رابط سایبر • کنترل و فرمان در یک نقطه', style: TextStyle(color: Color(0xFF9FB4CB), fontSize: 12)),
  ]));
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({required this.feature, required this.index, required this.onTap});
  final FeatureInfo feature; final int index; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(color: Colors.transparent, child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(15), child: Ink(decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0x2239CFFF)), gradient: const LinearGradient(colors: [Color(0xCC111F31), Color(0xAA0B1422)])), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13), child: Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0x2227D9FF), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0x4435D9FF))), child: Icon(feature.icon, color: _cyan, size: 21)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(feature.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)), const SizedBox(height: 3), Text(feature.status, style: const TextStyle(color: Color(0xFF91A8C1), fontSize: 11))])), const Icon(Icons.chevron_left_rounded, color: Colors.white38)])))));
}

class _GlassPanel extends StatelessWidget {
  const _GlassPanel({required this.child, this.padding = const EdgeInsets.all(16)});
  final Widget child; final EdgeInsets padding;
  @override
  Widget build(BuildContext context) => Container(padding: padding, decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(21), border: Border.all(color: const Color(0x333BCFFF)), boxShadow: [BoxShadow(color: _blue.withOpacity(.08), blurRadius: 24, spreadRadius: 1)], gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xCC15253A), Color(0xCC0B1320)])), child: child);
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.text}); final String text;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: const Color(0x2227D9FF), borderRadius: BorderRadius.circular(30), border: Border.all(color: const Color(0x5542DFFF))), child: Text(text, style: const TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w600)));
}

class _CyberBackgroundPainter extends CustomPainter {
  _CyberBackgroundPainter(this.t); final double t;
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = const Color(0xFF1B83B5).withOpacity(.075)..strokeWidth = .6;
    for (double x = 0; x < size.width; x += 28) canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    for (double y = 0; y < size.height; y += 28) canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    final glow = Paint()..shader = RadialGradient(colors: [const Color(0xFF087EBA).withOpacity(.16), Colors.transparent]).createShader(Rect.fromCircle(center: Offset(size.width * (.8 + .04 * math.sin(t * math.pi * 2)), size.height * .12), radius: 230));
    canvas.drawRect(Offset.zero & size, glow);
    final line = Paint()..color = _cyan.withOpacity(.11)..strokeWidth = 1.1;
    final y = size.height * (.28 + .025 * math.sin(t * math.pi * 2));
    final path = Path()..moveTo(0, y)..lineTo(size.width * .18, y - 30)..lineTo(size.width * .31, y - 30)..lineTo(size.width * .36, y - 52);
    canvas.drawPath(path, line);
  }
  @override
  bool shouldRepaint(covariant _CyberBackgroundPainter oldDelegate) => oldDelegate.t != t;
}

class _OrbitalPainter extends CustomPainter {
  _OrbitalPainter(this.t); final double t;
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    for (int i = 0; i < 3; i++) {
      final p = Paint()..style = PaintingStyle.stroke..strokeWidth = (i == 0 ? 1.4 : .8)..color = _cyan.withOpacity(.38 - i * .08);
      canvas.drawCircle(c, 53 + i * 19, p);
    }
    canvas.save(); canvas.translate(c.dx, c.dy); canvas.rotate(t * math.pi * 2);
    final arc = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..strokeCap = StrokeCap.round..color = _cyan;
    canvas.drawArc(const Rect.fromLTRB(-82, -82, 82, 82), -.7, 1.45, false, arc);
    final dot = Offset(math.cos(t * math.pi * 2) * 82, math.sin(t * math.pi * 2) * 82);
    canvas.drawCircle(dot, 4, Paint()..color = Colors.white..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));
    canvas.drawCircle(dot, 2, Paint()..color = _cyan);
    canvas.restore();
  }
  @override
  bool shouldRepaint(covariant _OrbitalPainter oldDelegate) => oldDelegate.t != t;
}
