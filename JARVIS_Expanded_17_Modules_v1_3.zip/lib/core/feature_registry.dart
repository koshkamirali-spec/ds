import 'package:flutter/material.dart';
class FeatureInfo { final String id,title,status,description; final IconData icon; const FeatureInfo(this.id,this.title,this.status,this.description,this.icon); }
class FeatureRegistry {
 static const features=<FeatureInfo>[
 FeatureInfo('ai','هوش مصنوعی Gemini','نیازمند API','اتصال امن از طریق backend یا کلید تنظیم‌شده.',Icons.psychology),
 FeatureInfo('memory','حافظه','یادداشت و تاریخچه محلی','ذخیره یادداشت‌ها، وظایف و حداکثر ۱۰۰ پیام اخیر روی دستگاه.',Icons.memory),
 FeatureInfo('voice','دستیار صوتی','ورودی و خروجی صوتی','گفتار به متن و متن به گفتار با مجوز میکروفون.',Icons.mic),
 FeatureInfo('wake','Hey Jarvis','محدودیت سیستم‌عامل','فعال‌سازی پس‌زمینه نیازمند پیاده‌سازی native.',Icons.hearing),
 FeatureInfo('device','کنترل گوشی','تنظیمات و مجوزهای سیستم','فقط فرمان‌های مجاز سیستم‌عامل.',Icons.phone_android),
 FeatureInfo('vision','دوربین و بینایی','دوربین فعال؛ تحلیل تصویر نیازمند AI','پیش‌نمایش دوربین و ثبت عکس؛ تحلیل محتوای تصویر هنوز متصل نیست.',Icons.camera_alt),
 FeatureInfo('web','جست‌وجوی وب','بازکردن جست‌وجوگر','جست‌وجوی عبارت در مرورگر دستگاه؛ پاسخ وب داخل برنامه خلاصه نمی‌شود.',Icons.travel_explore),
 FeatureInfo('tools','ابزارهای روزانه','یادداشت، وظیفه، ساعت، تاریخ','فرمان‌های محلی و فهرست ابزارهای روزانه.',Icons.build),
 FeatureInfo('comms','ارتباطات','بازکردن تماس و پیامک','بازکردن برنامه تماس یا پیامک؛ ارسال و تماس نهایی با تأیید کاربر.',Icons.forum),
 FeatureInfo('emergency','امنیت اضطراری','تماس اضطراری با تأیید','بازکردن شماره اضطراری 112 پس از تأیید؛ مکان‌یابی و ارسال خودکار هشدار فعال نیست.',Icons.health_and_safety),
 FeatureInfo('media','رسانه','بازکردن YouTube Music','بازکردن سرویس موسیقی؛ کنترل پخش درون‌برنامه‌ای فعال نیست.',Icons.play_circle),
 FeatureInfo('modes','حالت‌های هوشمند','ذخیره پروفایل','ذخیره حالت عادی، تمرکز، رانندگی، خانه یا کار؛ خودکارسازی سیستم هنوز فعال نیست.',Icons.tune),
 FeatureInfo('custom','فرمان اختصاصی','فرمان‌های متنی ذخیره‌شونده','تعریف عبارت و پاسخ متنی سفارشی روی دستگاه.',Icons.rule),
 FeatureInfo('settings','تنظیمات','کلید Gemini و تنظیمات','ترجیحات و تنظیمات اتصال سرویس‌ها.',Icons.settings),
 FeatureInfo('architecture','معماری یکپارچه','سرویس‌های پایه جداشده','ثبت قابلیت‌ها، مسیریابی و سرویس‌ها.',Icons.account_tree),
 FeatureInfo('backend','بک‌اند و امنیت','نمونه ساختار','اسرار باید سمت سرور نگهداری شوند.',Icons.security),
 FeatureInfo('cicd','CI/CD','ساخت خودکار APK','ساخت Android؛ انتشار نیازمند امضا و تست.',Icons.rocket_launch),
 ];
}
