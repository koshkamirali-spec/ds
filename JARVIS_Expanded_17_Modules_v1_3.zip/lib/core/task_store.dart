import 'package:shared_preferences/shared_preferences.dart';

class TaskStore {
  static const _key='jarvis_notes';
  static const _tasksKey='jarvis_tasks';
  static const _historyKey='jarvis_history';
  Future<List<String>> all() async => (await SharedPreferences.getInstance()).getStringList(_key) ?? [];
  Future<void> add(String value) async { final p=await SharedPreferences.getInstance(); final list=p.getStringList(_key)??[]; list.add(value); await p.setStringList(_key,list); }
  Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_key);
  Future<List<String>> allTasks() async => (await SharedPreferences.getInstance()).getStringList(_tasksKey) ?? [];
  Future<void> addTask(String value) async { final p=await SharedPreferences.getInstance(); final list=p.getStringList(_tasksKey)??[]; list.add(value); await p.setStringList(_tasksKey,list); }
  Future<void> clearTasks() async => (await SharedPreferences.getInstance()).remove(_tasksKey);
  Future<void> addHistory(String value) async {
    final p=await SharedPreferences.getInstance();
    final list=p.getStringList(_historyKey)??[];
    list.add(value);
    if(list.length>100) list.removeAt(0);
    await p.setStringList(_historyKey,list);
  }
  Future<List<String>> history() async => (await SharedPreferences.getInstance()).getStringList(_historyKey)??[];
}
