import 'package:flutter/material.dart';
import 'core/app_shell.dart';
void main() => runApp(const JarvisApp());
class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'J.A.R.V.I.S', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00A8C7), brightness: Brightness.dark), useMaterial3: true),
    home: const AppShell(),
  );
}
