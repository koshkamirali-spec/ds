import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

class JarvisCameraScreen extends StatefulWidget {
  const JarvisCameraScreen({super.key});
  @override
  State<JarvisCameraScreen> createState() => _JarvisCameraScreenState();
}
class _JarvisCameraScreenState extends State<JarvisCameraScreen> {
  CameraController? controller;
  String? error;
  bool taking = false;
  @override
  void initState() { super.initState(); _init(); }
  Future<void> _init() async {
    try {
      final cameras = await availableCameras();
      if(cameras.isEmpty) throw Exception('دوربینی پیدا نشد.');
      final c = CameraController(cameras.first, ResolutionPreset.medium, enableAudio:false);
      await c.initialize();
      if(!mounted){ await c.dispose(); return; }
      setState(()=>controller=c);
    } catch(e) { if(mounted) setState(()=>error=e.toString()); }
  }
  @override
  void dispose(){ controller?.dispose(); super.dispose(); }
  Future<void> _capture() async {
    final c=controller;
    if(c==null || taking) return;
    setState(()=>taking=true);
    try {
      final image=await c.takePicture();
      if(mounted) await showDialog<void>(context:context,builder:(ctx)=>AlertDialog(
        title:const Text('عکس ثبت شد'),
        content:Text('عکس در مسیر موقت دستگاه ذخیره شد:\n${image.path}'),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('باشه'))],
      ));
    } catch(e) { if(mounted) setState(()=>error=e.toString()); }
    if(mounted) setState(()=>taking=false);
  }
  @override
  Widget build(BuildContext context)=>Scaffold(
    backgroundColor:const Color(0xFF070C16),
    appBar:AppBar(title:const Text('دوربین J.A.R.V.I.S'),backgroundColor:const Color(0xFF101B2B)),
    body:Center(child:error!=null?Padding(padding:const EdgeInsets.all(24),child:Text('دسترسی دوربین ممکن نشد:\n$error',textAlign:TextAlign.center)):
      controller==null?const CircularProgressIndicator():Column(children:[
        Expanded(child:CameraPreview(controller!)),
        Padding(padding:const EdgeInsets.all(20),child:FilledButton.icon(onPressed:taking?null:_capture,icon:const Icon(Icons.camera_alt),label:Text(taking?'در حال ثبت...':'گرفتن عکس'))),
      ])),
  );
}
