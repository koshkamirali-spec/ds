import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import '../core/task_store.dart';

class CommandRouter {
  final TaskStore store;
  CommandRouter(this.store);

  Future<String> handle(String raw) async {
    final q = raw.trim();
    final lower = q.toLowerCase();
    if (q.isEmpty) return 'فرمان خالی است.';
    final prefs = await SharedPreferences.getInstance();
    final custom = prefs.getStringList('jarvis_custom_commands') ?? [];
    for (final item in custom) {
      final split = item.indexOf('|');
      if (split > 0 && item.substring(0, split).trim() == q) {
        return item.substring(split + 1);
      }
    }

    if (['سلام','hello','hi','درود'].contains(lower)) return 'سلام! سیستم آماده است. چه کاری انجام بدهم؟';

    if (q.startsWith('یادداشت ')) {
      final value = q.substring('یادداشت '.length).trim();
      if (value.isEmpty) return 'متن یادداشت خالی است.';
      await store.add(value);
      return 'یادداشت ذخیره شد: $value';
    }
    if (q == 'یادداشت‌ها' || q == 'یادداشت ها') {
      final items = await store.all();
      return items.isEmpty ? 'هنوز یادداشتی ثبت نشده.' :
          items.asMap().entries.map((e) => '${e.key + 1}. ${e.value}').join('\n');
    }
    if (q == 'پاک کردن یادداشت‌ها' || q == 'پاک کردن یادداشت ها') {
      await store.clear();
      return 'یادداشت‌های محلی پاک شدند.';
    }
    if (q.startsWith('وظیفه ' ) || q.startsWith('کار ')) {
      final value = q.substring(q.indexOf(' ') + 1).trim();
      if (value.isEmpty) return 'متن وظیفه را بعد از «وظیفه» بنویس.';
      await store.addTask(value);
      return 'وظیفه ثبت شد: $value';
    }
    if (q == 'وظایف' || q == 'کارها') {
      final items = await store.allTasks();
      return items.isEmpty ? 'فهرست وظایف خالی است.' :
          items.asMap().entries.map((e) => '${e.key + 1}. ${e.value}').join('\n');
    }
    if (lower.contains('ساعت') && (lower.contains('چند') || lower == 'ساعت')) {
      return 'ساعت محلی دستگاه: ${DateFormat('HH:mm').format(DateTime.now())}';
    }
    if (lower.contains('تاریخ') || lower == 'امروز') {
      return 'تاریخ امروز: ${DateFormat('yyyy/MM/dd').format(DateTime.now())}';
    }
    if (q.startsWith('جستجو ') || q.startsWith('جست‌وجو ')) {
      final term = q.substring(q.indexOf(' ') + 1).trim();
      if (term.isEmpty) return 'عبارت جستجو را بنویس.';
      await launchUrl(Uri.parse('https://www.google.com/search?q=${Uri.encodeQueryComponent(term)}'), mode: LaunchMode.externalApplication);
      return 'جست‌وجوی «$term» در مرورگر باز شد.';
    }
    if (q.startsWith('نقشه ') || q.startsWith('مسیریابی ')) {
      final term = q.substring(q.indexOf(' ') + 1).trim();
      if (term.isEmpty) return 'مقصد را بعد از «نقشه» بنویس.';
      await launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=${Uri.encodeQueryComponent(term)}'), mode: LaunchMode.externalApplication);
      return 'نقشه مقصد باز شد: $term';
    }

    if (q == 'موقعیت من' || q == 'مسیریابی از موقعیت من') {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) return 'مکان‌یابی دستگاه خاموش است. ابتدا Location را روشن کن.';
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        return 'مجوز مکان داده نشد. می‌توانی از تنظیمات برنامه مجوز Location را فعال کنی.';
      }
      final pos = await Geolocator.getCurrentPosition();
      await launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=${pos.latitude},${pos.longitude}'), mode: LaunchMode.externalApplication);
      return 'موقعیت فعلی روی نقشه باز شد.';
    }

    if (lower.contains('آب و هوا') || lower.contains('هواشناسی')) {
      await launchUrl(Uri.parse('https://www.google.com/search?q=${Uri.encodeQueryComponent('آب و هوای امروز')}'), mode: LaunchMode.externalApplication);
      return 'صفحه هواشناسی در مرورگر باز شد.';
    }
    if (q.startsWith('تماس ')) {
      final number = q.substring('تماس '.length).trim();
      if (number.isEmpty) return 'شماره تماس را وارد کن.';
      await launchUrl(Uri(scheme: 'tel', path: number));
      return 'برنامه تماس برای $number باز شد؛ برقراری تماس را خودت تأیید کن.';
    }
    if (q.startsWith('پیامک ')) {
      final parts = q.substring('پیامک '.length).split('|');
      if (parts.length < 2 || parts[0].trim().isEmpty) return 'قالب: پیامک شماره|متن پیام';
      await launchUrl(Uri(scheme: 'sms', path: parts[0].trim(), queryParameters: {'body': parts.sublist(1).join('|').trim()}));
      return 'صفحه پیامک باز شد؛ ارسال پیام فقط با تأیید خودت انجام می‌شود.';
    }
    if (lower == 'موسیقی' || lower == 'پخش موسیقی') {
      await launchUrl(Uri.parse('https://music.youtube.com/'), mode: LaunchMode.externalApplication);
      return 'YouTube Music باز شد.';
    }
    return 'این فرمان محلی شناخته نشد. اگر Gemini را در تنظیمات فعال کرده باشی، می‌توانم برای پاسخ هوشمند از آن استفاده کنم.';
  }
}
