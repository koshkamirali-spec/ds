import 'dart:convert';
import 'package:http/http.dart' as http;

class GeminiService {
  static const _endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

  Future<String> ask({required String apiKey, required String prompt}) async {
    final uri = Uri.parse('$_endpoint?key=${Uri.encodeQueryComponent(apiKey)}');
    final response = await http.post(
      uri,
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode({
        'system_instruction': {
          'parts': [{'text': 'You are J.A.R.V.I.S, a helpful Persian-speaking mobile assistant. Reply naturally and concisely in Persian unless the user asks otherwise. Never claim to have performed phone actions unless an available tool actually did them.'}]
        },
        'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
        'generationConfig': {'temperature': 0.7, 'maxOutputTokens': 900}
      }),
    ).timeout(const Duration(seconds: 35));
    if (response.statusCode != 200) {
      String detail = 'HTTP ${response.statusCode}';
      try {
        final data = jsonDecode(response.body);
        detail = data['error']?['message']?.toString() ?? detail;
      } catch (_) {}
      throw Exception('خطای Gemini: $detail');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final candidates = data['candidates'] as List?;
    if (candidates == null || candidates.isEmpty) return 'پاسخی از Gemini دریافت نشد.';
    final parts = candidates.first['content']?['parts'] as List? ?? [];
    final text = parts.map((part) => part['text']?.toString() ?? '').join('\n').trim();
    return text.isEmpty ? 'پاسخ خالی دریافت شد.' : text;
  }
}
