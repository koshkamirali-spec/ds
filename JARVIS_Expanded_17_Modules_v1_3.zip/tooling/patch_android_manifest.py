from pathlib import Path

manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists():
    raise SystemExit('AndroidManifest.xml not found; run flutter create first.')
text = manifest.read_text(encoding='utf-8')
permissions = [
    '    <uses-permission android:name="android.permission.INTERNET" />',
    '    <uses-permission android:name="android.permission.RECORD_AUDIO" />',
    '    <uses-permission android:name="android.permission.CAMERA" />',
]
for permission in permissions:
    if permission.strip() not in text:
        text = text.replace('<manifest', '<manifest', 1)
        insert_at = text.find('>', text.find('<manifest')) + 1
        text = text[:insert_at] + '\n' + permission + text[insert_at:]
queries = '''\n    <queries>\n        <intent>\n            <action android:name="android.speech.RecognitionService" />\n        </intent>\n    </queries>\n'''
if '<queries>' not in text:
    insert_at = text.find('>', text.find('<manifest')) + 1
    # Place queries after permissions, before application.
    app_at = text.find('<application')
    text = text[:app_at] + queries + text[app_at:]
manifest.write_text(text, encoding='utf-8')
print('Android internet, microphone, and camera permissions configured.')
